import {
  useState,
  type CSSProperties,
  type FormEvent,
  type ReactNode,
} from "react";

type IconName =
  | "home"
  | "sparkles"
  | "search"
  | "bookmark"
  | "calendar"
  | "settings"
  | "help"
  | "bell"
  | "chevron"
  | "upload"
  | "document"
  | "play"
  | "book"
  | "clock"
  | "plus"
  | "arrow"
  | "menu"
  | "close"
  | "mail"
  | "lock"
  | "eye"
  | "user";

function Icon({
  name,
  className = "h-5 w-5",
}: {
  name: IconName;
  className?: string;
}) {
  const paths: Record<IconName, ReactNode> = {
    home: (
      <>
        <path d="m3 10.8 9-7.4 9 7.4" />
        <path d="M5.5 9.3v10.2h13V9.3M9.5 19.5v-6h5v6" />
      </>
    ),
    sparkles: (
      <>
        <path d="m12 3 1.1 3.1L16 7.2l-2.9 1.1L12 11l-1.1-2.7L8 7.2l2.9-1.1L12 3Z" />
        <path d="m5.5 12 .9 2.6L9 15.5l-2.6.9L5.5 19l-.9-2.6-2.6-.9 2.6-.9.9-2.6ZM18.5 12l.7 2.1 2.1.7-2.1.7-.7 2.1-.7-2.1-2.1-.7 2.1-.7.7-2.1Z" />
      </>
    ),
    search: (
      <>
        <circle cx="10.8" cy="10.8" r="6.8" />
        <path d="m16 16 4 4" />
      </>
    ),
    bookmark: <path d="M6 3.5h12v17L12 17l-6 3.5v-17Z" />,
    calendar: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="2" />
        <path d="M7 3v4M17 3v4M3 10h18" />
      </>
    ),
    settings: (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.6v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" />
      </>
    ),
    help: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M9.7 9a2.4 2.4 0 0 1 4.6 1c0 1.8-2.3 2-2.3 3.5M12 17.4v.1" />
      </>
    ),
    bell: (
      <>
        <path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 8.5h18C21 16 18 16 18 9Z" />
        <path d="M14.2 20a2.5 2.5 0 0 1-4.4 0" />
      </>
    ),
    chevron: <path d="m9 18 6-6-6-6" />,
    upload: (
      <>
        <path d="M12 16V4M7.5 8.5 12 4l4.5 4.5" />
        <path d="M5 13v6h14v-6" />
      </>
    ),
    document: (
      <>
        <path d="M6 2.8h8l4 4v14.4H6V2.8Z" />
        <path d="M14 2.8v4h4M9 12h6M9 16h6" />
      </>
    ),
    play: (
      <>
        <rect x="2.5" y="5" width="19" height="14" rx="3" />
        <path d="m10 9 5 3-5 3V9Z" />
      </>
    ),
    book: (
      <>
        <path d="M4 4.5h6.5A1.5 1.5 0 0 1 12 6v14a2.5 2.5 0 0 0-2.5-2.5H4v-13ZM20 4.5h-6.5A1.5 1.5 0 0 0 12 6v14a2.5 2.5 0 0 1 2.5-2.5H20v-13Z" />
      </>
    ),
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3.5 2" />
      </>
    ),
    plus: <path d="M12 5v14M5 12h14" />,
    arrow: <path d="M5 12h14M14 7l5 5-5 5" />,
    menu: <path d="M4 7h16M4 12h16M4 17h16" />,
    close: <path d="m6 6 12 12M18 6 6 18" />,
    mail: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <path d="m4 7 8 6 8-6" />
      </>
    ),
    lock: (
      <>
        <rect x="5" y="10" width="14" height="11" rx="2" />
        <path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3" />
      </>
    ),
    eye: (
      <>
        <path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" />
        <circle cx="12" cy="12" r="2.5" />
      </>
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4.5 21a7.5 7.5 0 0 1 15 0" />
      </>
    ),
  };

  return (
    <svg
      aria-hidden="true"
      className={className}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

const navItems: { label: string; icon: IconName }[] = [
  { label: "Overview", icon: "home" },
  { label: "AI Summaries", icon: "sparkles" },
  { label: "Find Materials", icon: "search" },
  { label: "Saved Library", icon: "bookmark" },
  { label: "Study Planner", icon: "calendar" },
];

const modules = [
  {
    code: "INF 214",
    title: "Information Science",
    detail: "12 summaries",
    color: "#EF7F62",
    pale: "#FFF0EA",
  },
  {
    code: "COS 226",
    title: "Data Structures",
    detail: "8 summaries",
    color: "#58A99F",
    pale: "#E6F4F1",
  },
  {
    code: "INF 271",
    title: "Systems Analysis",
    detail: "5 summaries",
    color: "#E4AD55",
    pale: "#FFF6DF",
  },
];

function AuthPage({ onSuccess }: { onSuccess: () => void }) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [showPassword, setShowPassword] = useState(false);

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    onSuccess();
  };

  return (
    <main className="min-h-screen bg-[#F6F8F5] text-[#162A3A] lg:grid lg:grid-cols-[minmax(440px,0.92fr)_minmax(520px,1.08fr)]">
      <section className="relative hidden min-h-screen overflow-hidden bg-[#173C46] p-12 text-white lg:flex lg:flex-col xl:p-16">
        <div className="auth-orbit auth-orbit-one" />
        <div className="auth-orbit auth-orbit-two" />
        <div className="relative z-10 flex items-center gap-3">
          <div className="logo-mark bg-white">
            <span />
            <span />
            <span />
          </div>
          <div>
            <p className="font-display text-[18px] font-extrabold leading-none tracking-[-0.03em]">
              Varsity
            </p>
            <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.2em] text-[#9CC9C1]">
              Companion
            </p>
          </div>
        </div>

        <div className="relative z-10 my-auto max-w-[530px] pb-6">
          <p className="mb-5 text-[11px] font-extrabold uppercase tracking-[0.2em] text-[#7FC1B6]">
            Your academic operating system
          </p>
          <h1 className="font-display text-[44px] font-extrabold leading-[1.08] tracking-[-0.045em] xl:text-[54px]">
            Study smarter.
            <br />
            Stress{" "}
            <span className="relative text-[#F08A6F]">
              less.
              <svg
                className="absolute -bottom-2 left-0 w-full text-[#F08A6F]/55"
                viewBox="0 0 160 10"
                fill="none"
              >
                <path d="M2 7C44 2 106 2 158 5" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
              </svg>
            </span>
          </h1>
          <p className="mt-7 max-w-[460px] text-[15px] leading-7 text-[#B8CECE]">
            Course-aware summaries, trusted study materials and reliable offline
            access, built for South African student life.
          </p>

          <div className="mt-12 grid max-w-[500px] grid-cols-3 gap-3">
            {[
              ["01", "Summarise", "Turn dense notes into clear study points."],
              ["02", "Discover", "Find resources matched to your modules."],
              ["03", "Keep going", "Study with less data, even when offline."],
            ].map(([number, title, detail]) => (
              <div
                key={number}
                className="rounded-2xl border border-white/10 bg-white/[0.06] p-4 backdrop-blur-sm"
              >
                <span className="text-[10px] font-extrabold text-[#74B7AC]">{number}</span>
                <p className="mt-4 text-xs font-extrabold">{title}</p>
                <p className="mt-2 text-[10px] leading-relaxed text-[#9FB9B8]">{detail}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="relative z-10 flex items-center gap-2 text-[10px] text-[#83A3A1]">
          <span className="h-1.5 w-1.5 rounded-full bg-[#67B4A7]" />
          Built for low-data, real-life learning.
        </div>
      </section>

      <section className="flex min-h-screen items-center justify-center px-5 py-10 sm:px-10 lg:px-14">
        <div className="w-full max-w-[450px]">
          <div className="mb-12 flex items-center gap-3 lg:hidden">
            <div className="logo-mark">
              <span />
              <span />
              <span />
            </div>
            <div>
              <p className="font-display text-[17px] font-extrabold leading-none tracking-[-0.03em]">
                Varsity
              </p>
              <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.2em] text-[#71807D]">
                Companion
              </p>
            </div>
          </div>

          <div className="mb-8">
            <p className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#579286]">
              {mode === "login" ? "Welcome back" : "Start studying smarter"}
            </p>
            <h2 className="font-display text-[30px] font-extrabold tracking-[-0.035em] sm:text-[36px]">
              {mode === "login" ? "Good to see you again." : "Create your account."}
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-[#74827F]">
              {mode === "login"
                ? "Sign in to continue to your study space."
                : "Set up your free account. It only takes a minute."}
            </p>
          </div>

          <div className="mb-7 grid grid-cols-2 rounded-xl bg-[#E9EFEC] p-1">
            <button
              type="button"
              onClick={() => setMode("login")}
              className={`rounded-[9px] py-2.5 text-xs font-extrabold transition ${
                mode === "login"
                  ? "bg-white text-[#173C46] shadow-sm"
                  : "text-[#788784]"
              }`}
            >
              Log in
            </button>
            <button
              type="button"
              onClick={() => setMode("signup")}
              className={`rounded-[9px] py-2.5 text-xs font-extrabold transition ${
                mode === "signup"
                  ? "bg-white text-[#173C46] shadow-sm"
                  : "text-[#788784]"
              }`}
            >
              Sign up
            </button>
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === "signup" && (
              <label className="block">
                <span className="mb-2 block text-[11px] font-bold text-[#435956]">
                  Full name
                </span>
                <span className="relative block">
                  <Icon
                    name="user"
                    className="absolute left-4 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-[#879491]"
                  />
                  <input
                    required
                    autoComplete="name"
                    placeholder="e.g. Thando Mokoena"
                    className="h-13 w-full rounded-xl border border-[#D9E2DE] bg-white pl-11 pr-4 text-xs outline-none transition placeholder:text-[#A3ADAA] focus:border-[#5CA599] focus:ring-3 focus:ring-[#5CA599]/10"
                  />
                </span>
              </label>
            )}

            <label className="block">
              <span className="mb-2 block text-[11px] font-bold text-[#435956]">
                Email address
              </span>
              <span className="relative block">
                <Icon
                  name="mail"
                  className="absolute left-4 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-[#879491]"
                />
                <input
                  required
                  type="email"
                  autoComplete="email"
                  placeholder="student@university.ac.za"
                  className="h-13 w-full rounded-xl border border-[#D9E2DE] bg-white pl-11 pr-4 text-xs outline-none transition placeholder:text-[#A3ADAA] focus:border-[#5CA599] focus:ring-3 focus:ring-[#5CA599]/10"
                />
              </span>
            </label>

            <label className="block">
              <span className="mb-2 flex items-center justify-between text-[11px] font-bold text-[#435956]">
                Password
                {mode === "login" && (
                  <button
                    type="button"
                    className="font-bold text-[#478B80] hover:text-[#286D64]"
                  >
                    Forgot password?
                  </button>
                )}
              </span>
              <span className="relative block">
                <Icon
                  name="lock"
                  className="absolute left-4 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-[#879491]"
                />
                <input
                  required
                  minLength={6}
                  type={showPassword ? "text" : "password"}
                  autoComplete={mode === "login" ? "current-password" : "new-password"}
                  placeholder={mode === "login" ? "Enter your password" : "At least 6 characters"}
                  className="h-13 w-full rounded-xl border border-[#D9E2DE] bg-white pl-11 pr-12 text-xs outline-none transition placeholder:text-[#A3ADAA] focus:border-[#5CA599] focus:ring-3 focus:ring-[#5CA599]/10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-[#879491] hover:text-[#435956]"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  <Icon name="eye" className="h-[18px] w-[18px]" />
                </button>
              </span>
            </label>

            {mode === "signup" && (
              <label className="flex items-start gap-3 pt-1 text-[10px] leading-relaxed text-[#74827F]">
                <input
                  required
                  type="checkbox"
                  className="mt-0.5 h-4 w-4 accent-[#3E8D82]"
                />
                <span>
                  I agree to the{" "}
                  <button type="button" className="font-bold text-[#397F75]">
                    Terms of Use
                  </button>{" "}
                  and{" "}
                  <button type="button" className="font-bold text-[#397F75]">
                    Privacy Policy
                  </button>
                  .
                </span>
              </label>
            )}

            <button
              type="submit"
              className="flex h-13 w-full items-center justify-center gap-2 rounded-xl bg-[#173C46] text-xs font-extrabold text-white shadow-lg shadow-[#173C46]/10 transition hover:bg-[#21515A] focus:ring-4 focus:ring-[#5CA599]/20"
            >
              {mode === "login" ? "Log in to your account" : "Create free account"}
              <Icon name="arrow" className="h-4 w-4" />
            </button>
          </form>

          <div className="my-7 flex items-center gap-3">
            <span className="h-px flex-1 bg-[#DEE5E1]" />
            <span className="text-[9px] font-bold uppercase tracking-[0.16em] text-[#929D9A]">
              Secure student access
            </span>
            <span className="h-px flex-1 bg-[#DEE5E1]" />
          </div>

          <div className="flex items-center justify-center gap-2 text-center text-[11px] text-[#75827F]">
            <Icon name="lock" className="h-3.5 w-3.5 text-[#579286]" />
            Your study data stays private and protected.
          </div>
        </div>
      </section>
    </main>
  );
}

export default function App() {
  const [authenticated, setAuthenticated] = useState(false);
  const [activeNav, setActiveNav] = useState("Overview");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [summaryMode, setSummaryMode] = useState<"upload" | "paste">("upload");
  const [searchValue, setSearchValue] = useState("");
  const [toast, setToast] = useState("");

  const notify = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2200);
  };

  if (!authenticated) {
    return <AuthPage onSuccess={() => setAuthenticated(true)} />;
  }

  return (
    <div className="min-h-screen bg-[#F7F8F5] text-[#162A3A]">
      {toast && (
        <div className="fixed right-5 top-5 z-50 rounded-xl bg-[#173C46] px-4 py-3 text-sm font-semibold text-white shadow-xl">
          {toast}
        </div>
      )}

      {mobileOpen && (
        <button
          aria-label="Close navigation"
          className="fixed inset-0 z-30 bg-[#102D36]/30 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-[264px] flex-col border-r border-[#DCE5E1] bg-[#FBFCFA] px-4 pb-6 pt-7 transition-transform lg:translate-x-0 ${
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="mb-9 flex items-center justify-between px-3">
          <div className="flex items-center gap-3">
            <div className="logo-mark">
              <span />
              <span />
              <span />
            </div>
            <div>
              <p className="font-display text-[17px] font-extrabold leading-none tracking-[-0.03em]">
                Varsity
              </p>
              <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.2em] text-[#71807D]">
                Companion
              </p>
            </div>
          </div>
          <button
            className="rounded-lg p-1.5 text-[#6B7B7A] lg:hidden"
            onClick={() => setMobileOpen(false)}
            aria-label="Close menu"
          >
            <Icon name="close" />
          </button>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => {
                setActiveNav(item.label);
                setMobileOpen(false);
                if (item.label !== "Overview") {
                  notify(`${item.label} is ready for your next session`);
                }
              }}
              className={`flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-left text-[13px] font-semibold transition ${
                activeNav === item.label
                  ? "bg-[#DCEDEA] text-[#174D4D]"
                  : "text-[#60716F] hover:bg-[#EFF3F0] hover:text-[#173C46]"
              }`}
            >
              <Icon name={item.icon} className="h-[19px] w-[19px]" />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="mt-auto">
          <div className="mb-4 rounded-2xl border border-[#D4E4E0] bg-[#EEF6F3] p-4">
            <div className="mb-3 flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-[0.13em] text-[#526B68]">
                Weekly credits
              </span>
              <span className="text-xs font-extrabold text-[#1C5B56]">7 / 10</span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-[#D4E5E1]">
              <div className="h-full w-[70%] rounded-full bg-[#4FA497]" />
            </div>
            <p className="mt-3 text-[11px] leading-relaxed text-[#6C7E7B]">
              Resets Monday. Recent summaries are available offline.
            </p>
          </div>
          <button className="flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-[13px] font-semibold text-[#60716F] hover:bg-[#EFF3F0]">
            <Icon name="settings" className="h-[18px] w-[18px]" />
            Settings
          </button>
          <button className="flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-[13px] font-semibold text-[#60716F] hover:bg-[#EFF3F0]">
            <Icon name="help" className="h-[18px] w-[18px]" />
            Help & support
          </button>
          <button
            onClick={() => setAuthenticated(false)}
            className="mt-1 flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-[13px] font-semibold text-[#60716F] hover:bg-[#EFF3F0]"
          >
            <Icon name="arrow" className="h-[18px] w-[18px] rotate-180" />
            Sign out
          </button>
        </div>
      </aside>

      <div className="lg:pl-[264px]">
        <header className="sticky top-0 z-20 flex h-[76px] items-center border-b border-[#E0E6E2] bg-[#F7F8F5]/90 px-5 backdrop-blur-xl sm:px-8 lg:px-10">
          <button
            className="mr-3 rounded-lg p-2 text-[#24444A] lg:hidden"
            aria-label="Open menu"
            onClick={() => setMobileOpen(true)}
          >
            <Icon name="menu" />
          </button>

          <form
            className="relative hidden max-w-[390px] flex-1 md:block"
            onSubmit={(event) => {
              event.preventDefault();
              if (searchValue.trim()) notify(`Searching for “${searchValue}”`);
            }}
          >
            <Icon
              name="search"
              className="absolute left-3.5 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-[#82908E]"
            />
            <input
              value={searchValue}
              onChange={(event) => setSearchValue(event.target.value)}
              aria-label="Search study materials"
              placeholder="Search summaries, modules, materials..."
              className="h-10 w-full rounded-xl border border-[#DDE5E1] bg-white/70 pl-10 pr-4 text-xs outline-none transition placeholder:text-[#98A4A1] focus:border-[#6DAE9F] focus:ring-2 focus:ring-[#6DAE9F]/15"
            />
          </form>

          <div className="ml-auto flex items-center gap-3 sm:gap-5">
            <div className="hidden items-center gap-2 rounded-full border border-[#D8E2DE] bg-white px-3 py-1.5 text-[11px] font-bold text-[#58716D] sm:flex">
              <span className="h-2 w-2 rounded-full bg-[#60A99B]" />
              Low-data mode
            </div>
            <button
              onClick={() => notify("You’re all caught up")}
              className="relative rounded-xl border border-[#DDE5E1] bg-white p-2.5 text-[#526B6B] transition hover:border-[#AFC7C1]"
              aria-label="Notifications"
            >
              <Icon name="bell" className="h-[18px] w-[18px]" />
              <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-[#EB765B] ring-2 ring-white" />
            </button>
            <button className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#173C46] text-xs font-extrabold text-white">
                TM
              </span>
              <span className="hidden text-left xl:block">
                <span className="block text-xs font-bold">Thando M.</span>
                <span className="block text-[10px] text-[#7F8D8A]">UP · B.IT</span>
              </span>
            </button>
          </div>
        </header>

        <main className="mx-auto max-w-[1440px] px-5 pb-12 pt-8 sm:px-8 lg:px-10">
          <section className="mb-7 flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="mb-1 text-[11px] font-extrabold uppercase tracking-[0.18em] text-[#5B8B82]">
                Wednesday, 11 September
              </p>
              <h1 className="font-display text-[30px] font-extrabold tracking-[-0.035em] text-[#142D38] sm:text-[36px]">
                Sharp, Thando.
              </h1>
              <p className="mt-1 text-sm text-[#73817E]">
                Let’s make today’s study session count.
              </p>
            </div>
            <button
              onClick={() => notify("Your library is synced for offline use")}
              className="flex items-center gap-2 rounded-xl border border-[#D8E1DD] bg-white px-3.5 py-2.5 text-xs font-bold text-[#4B6361] shadow-sm transition hover:border-[#9CBEB7]"
            >
              <span className="relative flex h-2.5 w-2.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#58A99F] opacity-50" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-[#58A99F]" />
              </span>
              Synced for offline
            </button>
          </section>

          <section className="mb-6 grid gap-6 xl:grid-cols-[minmax(0,1.6fr)_minmax(300px,0.75fr)]">
            <div className="hero-card relative overflow-hidden rounded-[24px] bg-[#173C46] p-6 text-white shadow-[0_20px_45px_rgba(23,60,70,0.12)] sm:p-8">
              <div className="relative z-10 max-w-[570px]">
                <div className="mb-5 flex w-fit items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.15em] text-[#CDE9E3]">
                  <Icon name="sparkles" className="h-3.5 w-3.5" />
                  Course-aware AI
                </div>
                <h2 className="font-display text-[25px] font-extrabold leading-tight tracking-[-0.025em] sm:text-[31px]">
                  Turn complex notes into
                  <br className="hidden sm:block" /> clear study points.
                </h2>
                <p className="mt-3 max-w-[480px] text-[13px] leading-relaxed text-[#C4D5D5]">
                  Upload a lecture, reading or assignment and get a structured
                  summary tailored to your module.
                </p>

                <div className="mt-6 rounded-2xl bg-white p-1.5 text-[#203C42] shadow-xl shadow-black/10">
                  <div className="flex gap-1 border-b border-[#E7ECE9] p-1">
                    <button
                      onClick={() => setSummaryMode("upload")}
                      className={`rounded-lg px-3 py-2 text-[11px] font-bold transition ${
                        summaryMode === "upload"
                          ? "bg-[#E5F0ED] text-[#205A55]"
                          : "text-[#758380]"
                      }`}
                    >
                      Upload file
                    </button>
                    <button
                      onClick={() => setSummaryMode("paste")}
                      className={`rounded-lg px-3 py-2 text-[11px] font-bold transition ${
                        summaryMode === "paste"
                          ? "bg-[#E5F0ED] text-[#205A55]"
                          : "text-[#758380]"
                      }`}
                    >
                      Paste text
                    </button>
                  </div>
                  <div className="flex min-h-[88px] items-center justify-between gap-4 px-3 py-3 sm:px-4">
                    {summaryMode === "upload" ? (
                      <button
                        onClick={() => notify("File picker opened")}
                        className="flex min-w-0 flex-1 items-center gap-3 text-left"
                      >
                        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#FFF0EA] text-[#E27359]">
                          <Icon name="upload" className="h-5 w-5" />
                        </span>
                        <span className="min-w-0">
                          <span className="block truncate text-xs font-extrabold">
                            Drop a file here or browse
                          </span>
                          <span className="mt-1 block text-[10px] text-[#899693]">
                            PDF, DOCX or TXT · Max 20 MB
                          </span>
                        </span>
                      </button>
                    ) : (
                      <textarea
                        aria-label="Paste study notes"
                        className="h-16 flex-1 resize-none px-1 py-1 text-xs leading-relaxed outline-none placeholder:text-[#A1AAA8]"
                        placeholder="Paste lecture notes or assignment text here..."
                      />
                    )}
                    <button
                      onClick={() => notify("Select content to create your summary")}
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#EB765B] text-white transition hover:bg-[#D9654C]"
                      aria-label="Generate summary"
                    >
                      <Icon name="arrow" className="h-[18px] w-[18px]" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-[24px] border border-[#DEE5E1] bg-white p-6 shadow-[0_12px_30px_rgba(35,65,60,0.05)]">
              <div className="mb-5 flex items-start justify-between">
                <div>
                  <p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#7D8C89]">
                    Next up
                  </p>
                  <h3 className="mt-1 font-display text-lg font-extrabold">
                    Your deadlines
                  </h3>
                </div>
                <button
                  onClick={() => setActiveNav("Study Planner")}
                  className="text-[11px] font-bold text-[#41877C]"
                >
                  View planner
                </button>
              </div>
              <div className="space-y-3">
                <div className="group flex items-center gap-4 rounded-2xl bg-[#FFF6F1] p-3.5">
                  <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white text-center shadow-sm">
                    <span className="text-[9px] font-extrabold uppercase text-[#D46951]">Sep</span>
                    <span className="-mt-1 text-base font-extrabold text-[#243B42]">13</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-extrabold">Database Design Project</p>
                    <p className="mt-1 text-[10px] text-[#7D8886]">INF 214 · 23:59</p>
                  </div>
                  <span className="rounded-md bg-[#FADFD6] px-2 py-1 text-[9px] font-extrabold text-[#B9533E]">
                    2 days
                  </span>
                </div>
                <div className="flex items-center gap-4 rounded-2xl bg-[#F4F7F5] p-3.5">
                  <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white text-center shadow-sm">
                    <span className="text-[9px] font-extrabold uppercase text-[#5D7C77]">Sep</span>
                    <span className="-mt-1 text-base font-extrabold text-[#243B42]">18</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-extrabold">Trees & Graphs Test</p>
                    <p className="mt-1 text-[10px] text-[#7D8886]">COS 226 · 09:30</p>
                  </div>
                  <span className="rounded-md bg-[#E5EFEC] px-2 py-1 text-[9px] font-extrabold text-[#49766E]">
                    7 days
                  </span>
                </div>
              </div>
              <button
                onClick={() => notify("Add-deadline form opened")}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-[#C9D7D3] py-2.5 text-[11px] font-bold text-[#62807A] transition hover:bg-[#F1F6F4]"
              >
                <Icon name="plus" className="h-4 w-4" />
                Add deadline
              </button>
            </div>
          </section>

          <section className="mb-6">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#7D8C89]">
                  Personalised for you
                </p>
                <h2 className="mt-1 font-display text-xl font-extrabold">Your modules</h2>
              </div>
              <button
                onClick={() => notify("Module selector opened")}
                className="flex items-center gap-1.5 text-[11px] font-bold text-[#41877C]"
              >
                Manage modules
                <Icon name="chevron" className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              {modules.map((module, index) => (
                <button
                  key={module.code}
                  onClick={() => notify(`${module.code} selected`)}
                  className="module-card group overflow-hidden rounded-2xl border border-[#DEE5E1] bg-white p-5 text-left shadow-[0_8px_25px_rgba(35,65,60,0.04)] transition hover:-translate-y-0.5 hover:shadow-[0_12px_30px_rgba(35,65,60,0.08)]"
                  style={{ "--module-color": module.color } as CSSProperties}
                >
                  <div className="flex items-start justify-between">
                    <span
                      className="rounded-lg px-2.5 py-1.5 text-[10px] font-extrabold tracking-[0.08em]"
                      style={{ backgroundColor: module.pale, color: module.color }}
                    >
                      {module.code}
                    </span>
                    <span className="grid h-8 w-8 place-items-center rounded-full bg-[#F4F6F4] text-[#7B8986] transition group-hover:bg-[#173C46] group-hover:text-white">
                      <Icon name="arrow" className="h-3.5 w-3.5" />
                    </span>
                  </div>
                  <h3 className="mt-5 text-sm font-extrabold">{module.title}</h3>
                  <div className="mt-2 flex items-center justify-between text-[10px] text-[#84908D]">
                    <span>{module.detail}</span>
                    <span>{index === 0 ? "Last opened today" : `${index + 1} days ago`}</span>
                  </div>
                  <div className="mt-4 h-1 overflow-hidden rounded-full bg-[#EEF1EF]">
                    <div
                      className="h-full rounded-full"
                      style={{
                        backgroundColor: module.color,
                        width: `${72 - index * 13}%`,
                      }}
                    />
                  </div>
                </button>
              ))}
            </div>
          </section>

          <section className="grid gap-6 xl:grid-cols-[minmax(0,1.35fr)_minmax(300px,0.65fr)]">
            <div className="rounded-[22px] border border-[#DEE5E1] bg-white p-5 shadow-[0_8px_25px_rgba(35,65,60,0.04)] sm:p-6">
              <div className="mb-5 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#7D8C89]">
                    Pick up where you left off
                  </p>
                  <h2 className="mt-1 font-display text-lg font-extrabold">Recent activity</h2>
                </div>
                <button className="text-[11px] font-bold text-[#41877C]">View all</button>
              </div>
              <div className="divide-y divide-[#E7ECE9]">
                {[
                  {
                    icon: "document" as IconName,
                    title: "Relational database normalisation",
                    meta: "AI summary · INF 214",
                    time: "18 min ago",
                    bg: "#FFF0EA",
                    color: "#D96850",
                  },
                  {
                    icon: "play" as IconName,
                    title: "AVL trees explained visually",
                    meta: "Video resource · COS 226",
                    time: "Yesterday",
                    bg: "#E6F4F1",
                    color: "#468F85",
                  },
                  {
                    icon: "book" as IconName,
                    title: "Systems development life cycle",
                    meta: "Journal article · INF 271",
                    time: "2 days ago",
                    bg: "#FFF6DF",
                    color: "#B98532",
                  },
                ].map((item) => (
                  <button
                    key={item.title}
                    onClick={() => notify(`Opening ${item.title}`)}
                    className="flex w-full items-center gap-3.5 py-3.5 text-left first:pt-0 last:pb-0"
                  >
                    <span
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl"
                      style={{ backgroundColor: item.bg, color: item.color }}
                    >
                      <Icon name={item.icon} className="h-[18px] w-[18px]" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-xs font-extrabold">
                        {item.title}
                      </span>
                      <span className="mt-1 block text-[10px] text-[#83908D]">
                        {item.meta}
                      </span>
                    </span>
                    <span className="hidden items-center gap-1 text-[10px] text-[#8C9795] sm:flex">
                      <Icon name="clock" className="h-3.5 w-3.5" />
                      {item.time}
                    </span>
                    <Icon name="chevron" className="h-4 w-4 text-[#9BA5A3]" />
                  </button>
                ))}
              </div>
            </div>

            <div className="relative overflow-hidden rounded-[22px] bg-[#E7F2EF] p-6">
              <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full border-[20px] border-white/30" />
              <div className="relative">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#58A99F] text-white shadow-md shadow-[#58A99F]/20">
                  <Icon name="search" className="h-[19px] w-[19px]" />
                </span>
                <p className="mt-7 text-[10px] font-extrabold uppercase tracking-[0.15em] text-[#548078]">
                  Discover better sources
                </p>
                <h2 className="mt-2 font-display text-xl font-extrabold leading-snug">
                  Find materials made
                  <br /> for your modules.
                </h2>
                <p className="mt-3 text-[11px] leading-relaxed text-[#657C78]">
                  Search ranked videos, open journals and trusted resources in one place.
                </p>
                <button
                  onClick={() => {
                    setActiveNav("Find Materials");
                    notify("Materials search opened");
                  }}
                  className="mt-6 flex items-center gap-2 rounded-xl bg-[#173C46] px-4 py-3 text-[11px] font-bold text-white transition hover:bg-[#21505A]"
                >
                  Search materials
                  <Icon name="arrow" className="h-4 w-4" />
                </button>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
